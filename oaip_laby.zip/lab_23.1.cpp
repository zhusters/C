﻿#include <iostream>

using namespace std;

int
main()
{

	cout << 127 << ", ";

	cout.setf(ios::hex);		//LINE I

	cout << 127 << ", ";

	cout.setf(ios::showbase, ios::basefield);	//LINE II 

	cout << 127 << ", ";

	return 0;

}