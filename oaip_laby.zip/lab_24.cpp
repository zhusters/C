﻿#include <iostream>
#include<stack>

using namespace std;



struct Stack {
    char info;
    Stack* next;
};




int isOperator(char ch) {
    if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^')
        return 1;
    return -1;
}

int isOperand(char ch) {
    if (ch >= '0' && ch <= '9')
        return 1; 
   else
        return -1;
}

float operation(float a, float b, char op) {
    if (op == '+')
        return b + a;
    else if (op == '-')
        return b - a;
    else if (op == '*')
        return b * a;
    else if (op == '/')
        return b / a;
    else if (op == '^')
        return pow(b, a); //find b^a
    else
        return false; //return negative infinity
}



void res(string str) {
    char ch, ch1, ch2; 
    double b, a, res;
    stack<double> stk;
    for (int i = 1; i <= str.length(); i++) {
        ch = str[i];
        if (isOperator(ch) != -1) {
            a = stk.top();
            stk.pop();
            b = stk.top();
            stk.pop();
            stk.push(operation( b, a, ch));
        }
    }
    cout << stk.pop() << endl;


}
int main() {
    string root = "";
    cout << "The result is - " << endl;
    res(root);
}

